package com.example.jakeg.iteration2;

import android.content.Context;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    int ballCnt = 0;
    int strikeCnt = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button ballBtn = (Button ) findViewById(R.id.ballButton);
        ballBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ballCnt >= 3)
                {
                    AlertDialog.Builder a_builder = new AlertDialog.Builder(MainActivity.this);
                    a_builder.setMessage("WALK");
                    AlertDialog walkAlert = a_builder.create();
                    walkAlert.show();

                    ballCnt = 0;
                    strikeCnt = 0;
                }

                else {
                    ballCnt = ballCnt + 1;
                }
                    TextView ballEditText = findViewById(R.id.ballCounter);
                    TextView strikeEditText = findViewById(R.id.strikeCounter);
                    ballEditText.setText(ballCnt + "");
                    strikeEditText.setText(strikeCnt + "");


            }
        });

        Button strikeBtn = (Button ) findViewById(R.id.strikeButton);
        strikeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (strikeCnt >= 2)
                {
                    AlertDialog.Builder a_builder = new AlertDialog.Builder(MainActivity.this);
                    a_builder.setMessage("STRIKE");
                    AlertDialog walkAlert = a_builder.create();
                    walkAlert.show();

                    strikeCnt = 0;
                    ballCnt = 0;
                }
                else
                    {
                    strikeCnt = strikeCnt + 1;
                }



                TextView ballEditText = findViewById(R.id.ballCounter);
                TextView strikeEditText = findViewById(R.id.strikeCounter);
                ballEditText.setText(ballCnt + "");
                strikeEditText.setText(strikeCnt + "");









            }
        });
        }
    }


